#!/usr/bin/env bash
set -e

BIN_NAME="sina"
INSTALL_DIR="/usr/local/bin"

echo "Installing $BIN_NAME..."

if [ ! -w "$INSTALL_DIR" ]; then
  echo "Requesting sudo access..."
  sudo cp "sina" "$INSTALL_DIR/$BIN_NAME"
else
  cp "sina" "$INSTALL_DIR/$BIN_NAME"
fi

chmod +x "$INSTALL_DIR/$BIN_NAME"

echo "Installed successfully!"
echo "You can run any file using sina file_name"